<h2>Edit Pelanggan</h2>

<form action="<?php echo URL; ?>/Pelanggan/update" method="post">
    <input type="hidden" name="id" value="<?php echo $data['row']['pel_id']; ?>">
    <table>
        <tr>
            <td>ID PELANGGAN</td>
            <td><input type="text" name="pel_id" value="<?php echo $data['row']['pel_id']; ?>" required></td>
        </tr>
        <tr>
            <td>ID GOLONGAN</td>
            <td><input type="text" name="pel_id_gol" value="<?php echo $data['row']['pel_id_gol']; ?>" required></td>
        </tr>
        <tr>
            <td>NO PELANGGAN</td>
            <td><input type="text" name="pel_no" value="<?php echo $data['row']['pel_no']; ?>" required></td>
        </tr>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="pel_nama" value="<?php echo $data['row']['pel_nama']; ?>" required></td>
        </tr>
        <tr>
            <td>ALAMAT</td>
            <td><input type="text" name="pel_alamat" value="<?php echo $data['row']['pel_alamat']; ?>" required></td>
        </tr>
        <tr>
            <td>NO HP</td>
            <td><input type="text" name="cat_name" value="<?php echo $data['row']['pel_hp']; ?>" required></td>
        </tr>
        <tr>
            <td>KTP</td>
            <td><input type="text" name="pel_ktp" value="<?php echo $data['row']['pel_ktp']; ?>" required></td>
        </tr>
        <tr>
            <td>NO SERI</td>
            <td><input type="text" name="pel_seri" value="<?php echo $data['row']['pel_seri']; ?>" required></td>
        </tr>
        <tr>
            <td>NO METERAN</td>
            <td><input type="text" name="pel_meteran" value="<?php echo $data['row']['pel_meteran']; ?>" required></td>
        </tr> <tr>
            <td>AKTIF</td>
            <td><input type="text" name="pel_aktif" value="<?php echo $data['row']['pel_aktif']; ?>" required></td>
        </tr>
         <tr>
            <td>ID USER</td>
            <td><input type="text" name="pel_id_user" value="<?php echo $data['row']['pel_id_user']; ?>" required></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>