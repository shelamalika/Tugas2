<h2>Golongan</h2>

<a href="<?php echo URL; ?>/Golongan/input" class="btn">Add Golongan</a>

<table>
      <tr>
            <th>ID GOLONGAN</th>
            <th>KODE GOLONGAN</th>
            <th>NAMA</th>
            <th>EDIT</th>
            <th>DELETE</th>
      </tr>

      <?php $no = 1;
      foreach ($data['rows'] as $row) { ?>
            <tr>
                  <td><?php echo $no; ?></td>
                  
                  <td><?php echo $row['gol_kode']; ?></td>
                  <td><?php echo $row['gol_nama']; ?></td>
                  <td><a href="<?php echo URL; ?>/Golongan/edit/<?php echo $row['gol_id']; ?>" class="btn">Edit</a></td>
                  <td><a href="<?php echo URL; ?>/Golongan/delete/<?php echo $row['gol_id']; ?>" class="btn">Delete</a></td>
            </tr>
      <?php $no++;
      } ?>

</table>